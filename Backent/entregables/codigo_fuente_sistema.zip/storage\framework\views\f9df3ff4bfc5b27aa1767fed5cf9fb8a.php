<?php $__env->startSection('title', $company->business_name); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid p-0">
    <!-- Header -->
    <div class="d-flex flex-column flex-md-row align-items-md-center justify-content-between mb-4">
        <div>
            <div class="d-flex align-items-center gap-2 mb-1">
                <h3 class="fw-bold text-dark mb-0"><?php echo e($company->business_name); ?></h3>
                <span class="badge bg-light text-dark border"><?php echo e($company->industry_sector); ?></span>
                <?php if($company->is_active): ?>
                    <span class="badge bg-success">Activa</span>
                <?php else: ?>
                    <span class="badge bg-secondary">Inactiva</span>
                <?php endif; ?>
            </div>
            <p class="text-muted small mb-0">CUIT / RUC: <strong><?php echo e($company->tax_id); ?></strong> | Registrada por: <?php echo e($company->creator->name ?? 'Sistema'); ?></p>
        </div>
        <div class="mt-3 mt-md-0 d-flex gap-2">
            <a href="<?php echo e(route('companies.index')); ?>" class="btn btn-outline-secondary btn-touch">
                <i class="fa-solid fa-arrow-left me-1"></i> Volver
            </a>
            <a href="<?php echo e(route('companies.edit', $company)); ?>" class="btn btn-outline-primary btn-touch">
                <i class="fa-solid fa-pen-to-square me-1"></i> Editar
            </a>
            <a href="<?php echo e(route('inspections.create', ['company_id' => $company->id])); ?>" class="btn btn-warning btn-touch text-dark fw-bold shadow-sm">
                <i class="fa-solid fa-plus-circle me-1"></i> Nueva Inspección
            </a>
        </div>
    </div>

    <div class="row g-4 mb-4">
        <!-- Tarjeta de Información General -->
        <div class="col-lg-8">
            <div class="card card-custom h-100">
                <div class="card-header bg-white border-0 pt-3 px-4">
                    <h5 class="fw-bold text-dark mb-0"><i class="fa-solid fa-circle-info me-2 text-primary"></i> Datos Generales del Establecimiento</h5>
                </div>
                <div class="card-body px-4 pb-4">
                    <div class="row g-3">
                        <div class="col-sm-6">
                            <span class="text-muted small d-block">Dirección de Planta</span>
                            <span class="fw-semibold text-dark"><?php echo e($company->address ?? 'No especificada'); ?></span>
                        </div>
                        <div class="col-sm-6">
                            <span class="text-muted small d-block">Dotación de Personal</span>
                            <span class="fw-semibold text-dark"><i class="fa-solid fa-users me-1 text-secondary"></i> <?php echo e($company->employee_count); ?> trabajadores</span>
                        </div>
                        <div class="col-sm-6">
                            <span class="text-muted small d-block">Teléfono</span>
                            <span class="fw-semibold text-dark"><?php echo e($company->phone ?? 'No especificado'); ?></span>
                        </div>
                        <div class="col-sm-6">
                            <span class="text-muted small d-block">Correo Electrónico</span>
                            <span class="fw-semibold text-dark"><?php echo e($company->email ?? 'No especificado'); ?></span>
                        </div>
                        <div class="col-sm-6">
                            <span class="text-muted small d-block">Persona de Contacto</span>
                            <span class="fw-semibold text-dark"><?php echo e($company->contact_person ?? 'No especificado'); ?></span>
                        </div>
                        <div class="col-sm-6">
                            <span class="text-muted small d-block">Sitio Web</span>
                            <?php if($company->website): ?>
                                <a href="<?php echo e($company->website); ?>" target="_blank" class="fw-semibold text-primary text-decoration-none">
                                    <?php echo e($company->website); ?> <i class="fa-solid fa-arrow-up-right-from-square small ms-1"></i>
                                </a>
                            <?php else: ?>
                                <span class="text-muted">No especificado</span>
                            <?php endif; ?>
                        </div>
                    </div>

                    <hr class="my-4 text-muted">

                    <!-- Inspectores Responsables -->
                    <div class="d-flex align-items-center justify-content-between mb-3">
                        <h6 class="fw-bold text-dark mb-0"><i class="fa-solid fa-user-shield me-2 text-primary"></i> Licenciados Asignados</h6>
                        <?php if(auth()->user()->isAdmin()): ?>
                            <button type="button" class="btn btn-sm btn-outline-primary" data-bs-toggle="modal" data-bs-target="#assignModal">
                                <i class="fa-solid fa-user-plus me-1"></i> Asignar Inspectores
                            </button>
                        <?php endif; ?>
                    </div>

                    <div class="d-flex flex-wrap gap-2">
                        <?php $__empty_1 = true; $__currentLoopData = $company->inspectors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $insp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <div class="border rounded px-3 py-2 bg-light d-flex align-items-center">
                                <i class="fa-solid fa-id-badge text-primary fa-lg me-2"></i>
                                <div>
                                    <div class="fw-bold text-dark small"><?php echo e($insp->name); ?></div>
                                    <small class="text-muted"><?php echo e($insp->license_number ?? $insp->email); ?></small>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <p class="text-muted small mb-0">No hay inspectores asignados a esta empresa.</p>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>

        <!-- Tarjeta Código QR Dinámico (Entregable Opcional 1) -->
        <div class="col-lg-4">
            <div class="card card-custom h-100 text-center p-4 d-flex flex-column align-items-center justify-content-center">
                <div class="bg-light p-3 rounded-3 border mb-3 shadow-sm">
                    <?php
                        $qrData = route('companies.show', $company);
                        $qrUrl = 'https://api.qrserver.com/v1/create-qr-code/?size=160x160&data=' . urlencode($qrData);
                    ?>
                    <img src="<?php echo e($qrUrl); ?>" alt="Código QR Empresa" class="img-fluid" style="width: 150px; height: 150px;">
                </div>
                <h6 class="fw-bold text-dark mb-1">Código QR de la Empresa</h6>
                <p class="text-muted small mb-3">Escanee en el establecimiento para acceder al historial técnico de inspecciones.</p>
                <button type="button" class="btn btn-outline-secondary btn-sm" onclick="window.print()">
                    <i class="fa-solid fa-print me-1"></i> Imprimir Ficha / Cartel QR
                </button>
            </div>
        </div>
    </div>

    <!-- Historial de Inspecciones Realizadas (RF-17) -->
    <div class="card card-custom">
        <div class="card-header bg-white border-0 pt-3 px-4 d-flex justify-content-between align-items-center">
            <h5 class="fw-bold text-dark mb-0"><i class="fa-solid fa-clock-rotate-left me-2 text-primary"></i> Historial de Inspecciones en esta Empresa</h5>
            <a href="<?php echo e(route('inspections.create', ['company_id' => $company->id])); ?>" class="btn btn-sm btn-warning text-dark fw-bold">
                <i class="fa-solid fa-plus-circle me-1"></i> Iniciar Inspección
            </a>
        </div>
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0">
                    <thead class="table-light">
                        <tr>
                            <th>Fecha</th>
                            <th>Inspector Responsable</th>
                            <th>Tipo</th>
                            <th>Estado</th>
                            <th>Observaciones</th>
                            <th>Avance Checklist</th>
                            <th class="text-end">Acciones</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $company->inspections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ins): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td class="fw-semibold"><?php echo e($ins->inspection_date->format('d/m/Y')); ?></td>
                                <td><?php echo e($ins->user->name ?? 'N/A'); ?></td>
                                <td><span class="badge bg-secondary"><?php echo e($ins->type); ?></span></td>
                                <td>
                                    <span class="badge <?php echo e($ins->status === 'Completada' ? 'bg-success' : ($ins->status === 'En Progreso' ? 'bg-primary' : 'bg-warning text-dark')); ?>">
                                        <?php echo e($ins->status); ?>

                                    </span>
                                </td>
                                <td>
                                    <span class="badge bg-danger-subtle text-danger border border-danger-subtle">
                                        <?php echo e($ins->observations->count()); ?> hallazgos
                                    </span>
                                </td>
                                <td>
                                    <div class="d-flex align-items-center">
                                        <div class="progress flex-grow-1 me-2" style="height: 6px;">
                                            <div class="progress-bar <?php echo e($ins->progress_percentage == 100 ? 'bg-success' : 'bg-primary'); ?>" style="width: <?php echo e($ins->progress_percentage); ?>%;"></div>
                                        </div>
                                        <small class="fw-bold"><?php echo e($ins->progress_percentage); ?>%</small>
                                    </div>
                                </td>
                                <td class="text-end">
                                    <a href="<?php echo e(route('inspections.show', $ins)); ?>" class="btn btn-sm btn-primary">
                                        <i class="fa-solid fa-eye me-1"></i> Abrir
                                    </a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="7" class="text-center py-4 text-muted">
                                    No se registran inspecciones para esta empresa aún.
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<!-- Modal para Asignación de Inspectores (Admin) -->
<?php if(auth()->user()->isAdmin()): ?>
<div class="modal fade" id="assignModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog">
        <form action="<?php echo e(route('companies.assign', $company)); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title fw-bold">Asignar Inspectores a <?php echo e($company->business_name); ?></h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Cerrar"></button>
                </div>
                <div class="modal-body">
                    <p class="text-muted small mb-3">Marque los licenciados autorizados a realizar inspecciones en este establecimiento:</p>
                    <div class="d-flex flex-column gap-2">
                        <?php $__currentLoopData = $inspectors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $insp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="form-check p-2 border rounded">
                                <input class="form-check-input ms-0 me-2" type="checkbox" name="inspector_ids[]" value="<?php echo e($insp->id); ?>" id="modal_insp_<?php echo e($insp->id); ?>" <?php echo e($company->inspectors->contains('id', $insp->id) ? 'checked' : ''); ?>>
                                <label class="form-check-label fw-semibold" for="modal_insp_<?php echo e($insp->id); ?>">
                                    <?php echo e($insp->name); ?>

                                    <small class="text-muted d-block"><?php echo e($insp->license_number ?? $insp->email); ?></small>
                                </label>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-light border" data-bs-dismiss="modal">Cancelar</button>
                    <button type="submit" class="btn btn-primary">Guardar Asignaciones</button>
                </div>
            </div>
        </form>
    </div>
</div>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\murqu\.gemini\antigravity\scratch\sistema-inspecciones-hys\resources\views\companies\show.blade.php ENDPATH**/ ?>