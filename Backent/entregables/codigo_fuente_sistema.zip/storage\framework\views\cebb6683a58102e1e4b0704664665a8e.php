<?php $__env->startSection('title', 'Notificaciones del Sistema'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid p-0" style="max-width: 900px;">
    <div class="d-flex align-items-center justify-content-between mb-4">
        <div>
            <h3 class="fw-bold text-dark mb-1">Centro de Notificaciones</h3>
            <p class="text-muted small mb-0">Alertas de seguridad, vencimientos y avisos operativos</p>
        </div>
        <?php if(auth()->user()->unreadNotificationsCount() > 0): ?>
            <form action="<?php echo e(route('notifications.read-all')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <button type="submit" class="btn btn-outline-secondary btn-touch">
                    <i class="fa-solid fa-check-double me-1"></i> Marcar todas como leídas
                </button>
            </form>
        <?php endif; ?>
    </div>

    <div class="card card-custom">
        <div class="card-body p-0">
            <div class="list-group list-group-flush">
                <?php $__empty_1 = true; $__currentLoopData = $notifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notif): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="list-group-item p-3 <?php echo e($notif->is_read ? 'bg-white' : 'bg-light border-start border-primary border-4'); ?>">
                        <div class="d-flex align-items-start justify-content-between">
                            <div class="d-flex align-items-start">
                                <div class="me-3 mt-1">
                                    <?php if($notif->type === 'danger'): ?>
                                        <div class="bg-danger text-white rounded-circle p-2 d-flex align-items-center justify-content-center" style="width: 38px; height: 38px;">
                                            <i class="fa-solid fa-triangle-exclamation"></i>
                                        </div>
                                    <?php elseif($notif->type === 'warning'): ?>
                                        <div class="bg-warning text-dark rounded-circle p-2 d-flex align-items-center justify-content-center" style="width: 38px; height: 38px;">
                                            <i class="fa-solid fa-bell"></i>
                                        </div>
                                    <?php else: ?>
                                        <div class="bg-primary text-white rounded-circle p-2 d-flex align-items-center justify-content-center" style="width: 38px; height: 38px;">
                                            <i class="fa-solid fa-circle-info"></i>
                                        </div>
                                    <?php endif; ?>
                                </div>
                                <div>
                                    <h6 class="fw-bold text-dark mb-1"><?php echo e($notif->title); ?></h6>
                                    <p class="text-secondary small mb-1"><?php echo e($notif->message); ?></p>
                                    <small class="text-muted"><i class="fa-regular fa-clock me-1"></i> <?php echo e($notif->created_at->diffForHumans()); ?></small>
                                </div>
                            </div>

                            <div class="ms-3 text-end">
                                <?php if(!$notif->is_read): ?>
                                    <form action="<?php echo e(route('notifications.read', $notif)); ?>" method="POST">
                                        <?php echo csrf_field(); ?>
                                        <button type="submit" class="btn btn-sm btn-outline-primary text-nowrap">
                                            <?php echo e($notif->link ? 'Ver y Marcar' : 'Marcar Leída'); ?>

                                        </button>
                                    </form>
                                <?php elseif($notif->link): ?>
                                    <a href="<?php echo e($notif->link); ?>" class="btn btn-sm btn-light border text-nowrap">Ver</a>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <div class="p-5 text-center text-muted">
                        <i class="fa-regular fa-bell-slash fa-3x mb-3 text-secondary"></i>
                        <h6 class="fw-bold">No tienes notificaciones pendientes</h6>
                        <p class="small mb-0">Todas las novedades operativas aparecerán aquí.</p>
                    </div>
                <?php endif; ?>
            </div>
        </div>
        <?php if($notifications->hasPages()): ?>
            <div class="card-footer bg-white border-0 py-3">
                <?php echo e($notifications->links()); ?>

            </div>
        <?php endif; ?>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\murqu\.gemini\antigravity\scratch\sistema-inspecciones-hys\resources\views/notifications/index.blade.php ENDPATH**/ ?>