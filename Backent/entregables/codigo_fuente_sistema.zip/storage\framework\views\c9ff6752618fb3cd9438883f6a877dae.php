<?php $__env->startSection('title', 'Editar Empresa'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid p-0" style="max-width: 900px;">
    <div class="d-flex align-items-center justify-content-between mb-4">
        <div>
            <h3 class="fw-bold text-dark mb-1">Editar Empresa</h3>
            <p class="text-muted small mb-0"><?php echo e($company->business_name); ?> (CUIT: <?php echo e($company->tax_id); ?>)</p>
        </div>
        <a href="<?php echo e(route('companies.show', $company)); ?>" class="btn btn-outline-secondary btn-touch">
            <i class="fa-solid fa-arrow-left me-2"></i> Volver
        </a>
    </div>

    <div class="card card-custom">
        <div class="card-body p-4">
            <form action="<?php echo e(route('companies.update', $company)); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>

                <div class="row g-3">
                    <div class="col-md-8">
                        <label for="business_name" class="form-label fw-semibold">Razón Social <span class="text-danger">*</span></label>
                        <input type="text" name="business_name" id="business_name" class="form-control" value="<?php echo e(old('business_name', $company->business_name)); ?>" required>
                    </div>

                    <div class="col-md-4">
                        <label for="tax_id" class="form-label fw-semibold">CUIT / RUC <span class="text-danger">*</span></label>
                        <input type="text" name="tax_id" id="tax_id" class="form-control" value="<?php echo e(old('tax_id', $company->tax_id)); ?>" required>
                    </div>

                    <div class="col-md-6">
                        <label for="industry_sector" class="form-label fw-semibold">Sector Industrial <span class="text-danger">*</span></label>
                        <select name="industry_sector" id="industry_sector" class="form-select" required>
                            <?php
                                $sectors = ['Metalmecánica', 'Construcción', 'Química y Farmacéutica', 'Logística y Transporte', 'Alimentos y Bebidas', 'Agropecuario', 'Servicios y Comercio', 'Minería y Energía'];
                            ?>
                            <?php $__currentLoopData = $sectors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sec): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($sec); ?>" <?php echo e(old('industry_sector', $company->industry_sector) === $sec ? 'selected' : ''); ?>><?php echo e($sec); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>

                    <div class="col-md-6">
                        <label for="employee_count" class="form-label fw-semibold">Cantidad de Empleados <span class="text-danger">*</span></label>
                        <input type="number" name="employee_count" id="employee_count" class="form-control" value="<?php echo e(old('employee_count', $company->employee_count)); ?>" min="1" required>
                    </div>

                    <div class="col-md-12">
                        <label for="address" class="form-label fw-semibold">Dirección de la Planta</label>
                        <input type="text" name="address" id="address" class="form-control" value="<?php echo e(old('address', $company->address)); ?>">
                    </div>

                    <div class="col-md-6">
                        <label for="phone" class="form-label fw-semibold">Teléfono de Contacto</label>
                        <input type="text" name="phone" id="phone" class="form-control" value="<?php echo e(old('phone', $company->phone)); ?>">
                    </div>

                    <div class="col-md-6">
                        <label for="email" class="form-label fw-semibold">Correo Electrónico Institucional</label>
                        <input type="email" name="email" id="email" class="form-control" value="<?php echo e(old('email', $company->email)); ?>">
                    </div>

                    <div class="col-md-6">
                        <label for="contact_person" class="form-label fw-semibold">Persona de Contacto / Cargo</label>
                        <input type="text" name="contact_person" id="contact_person" class="form-control" value="<?php echo e(old('contact_person', $company->contact_person)); ?>">
                    </div>

                    <div class="col-md-6">
                        <label for="website" class="form-label fw-semibold">Sitio Web</label>
                        <input type="url" name="website" id="website" class="form-control" value="<?php echo e(old('website', $company->website)); ?>">
                    </div>

                    <?php if(auth()->user()->isAdmin()): ?>
                        <div class="col-12"><hr class="my-2 text-muted"></div>
                        <div class="col-12">
                            <label class="form-label fw-semibold">Inspectores Responsables Asignados</label>
                            <div class="row g-2">
                                <?php $__currentLoopData = $inspectors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $insp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="col-md-6">
                                        <div class="form-check p-2 border rounded">
                                            <input class="form-check-input ms-0 me-2" type="checkbox" name="inspector_ids[]" value="<?php echo e($insp->id); ?>" id="insp_<?php echo e($insp->id); ?>" <?php echo e($company->inspectors->contains('id', $insp->id) ? 'checked' : ''); ?>>
                                            <label class="form-check-label fw-semibold" for="insp_<?php echo e($insp->id); ?>">
                                                <?php echo e($insp->name); ?>

                                                <small class="text-muted d-block"><?php echo e($insp->license_number ?? $insp->email); ?></small>
                                            </label>
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                    <?php endif; ?>

                    <div class="col-12 mt-3">
                        <div class="form-check form-switch">
                            <input class="form-check-input" type="checkbox" role="switch" id="is_active" name="is_active" value="1" <?php echo e(old('is_active', $company->is_active) ? 'checked' : ''); ?>>
                            <label class="form-check-label fw-semibold" for="is_active">Empresa Activa</label>
                        </div>
                    </div>

                    <div class="col-12 mt-4 text-end">
                        <a href="<?php echo e(route('companies.show', $company)); ?>" class="btn btn-light border btn-touch px-3 me-2">Cancelar</a>
                        <button type="submit" class="btn btn-primary btn-touch px-4">
                            <i class="fa-solid fa-floppy-disk me-2"></i> Actualizar Empresa
                        </button>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\murqu\.gemini\antigravity\scratch\sistema-inspecciones-hys\resources\views/companies/edit.blade.php ENDPATH**/ ?>