<?php $__env->startSection('title', 'Matriz de Medidas Correctivas'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid p-0">
    <div class="d-flex flex-column flex-md-row align-items-md-center justify-content-between mb-4">
        <div>
            <h3 class="fw-bold text-dark mb-1">Matriz de Medidas Correctivas y Preventivas</h3>
            <p class="text-muted small mb-0">Seguimiento de acciones requeridas, plazos de vencimiento y responsables</p>
        </div>
    </div>

    <!-- Mini KPIs -->
    <div class="row g-3 mb-4">
        <div class="col-sm-4">
            <div class="card card-custom p-3 border-start border-primary border-4">
                <span class="text-muted small text-uppercase fw-bold">Total Registradas</span>
                <h3 class="fw-bold text-dark mb-0 mt-1"><?php echo e($totalCount); ?></h3>
            </div>
        </div>
        <div class="col-sm-4">
            <div class="card card-custom p-3 border-start border-warning border-4">
                <span class="text-muted small text-uppercase fw-bold">En Seguimiento</span>
                <h3 class="fw-bold text-warning mb-0 mt-1"><?php echo e($pendingCount); ?></h3>
            </div>
        </div>
        <div class="col-sm-4">
            <div class="card card-custom p-3 border-start border-danger border-4">
                <span class="text-muted small text-uppercase fw-bold">Vencidas</span>
                <h3 class="fw-bold text-danger mb-0 mt-1"><?php echo e($overdueCount); ?></h3>
            </div>
        </div>
    </div>

    <!-- Filtros -->
    <div class="card card-custom mb-4">
        <div class="card-body p-3">
            <form action="<?php echo e(route('corrective-measures.index')); ?>" method="GET" class="row g-2 align-items-center">
                <div class="col-md-3">
                    <select name="status" class="form-select">
                        <option value="">Todos los estados</option>
                        <option value="Pendiente" <?php echo e(request('status') === 'Pendiente' ? 'selected' : ''); ?>>Pendiente</option>
                        <option value="En Progreso" <?php echo e(request('status') === 'En Progreso' ? 'selected' : ''); ?>>En Progreso</option>
                        <option value="Completada" <?php echo e(request('status') === 'Completada' ? 'selected' : ''); ?>>Completada</option>
                        <option value="Vencida" <?php echo e(request('status') === 'Vencida' ? 'selected' : ''); ?>>Vencida</option>
                        <option value="Cancelada" <?php echo e(request('status') === 'Cancelada' ? 'selected' : ''); ?>>Cancelada</option>
                    </select>
                </div>
                <div class="col-md-3">
                    <select name="priority" class="form-select">
                        <option value="">Todas las prioridades</option>
                        <option value="Crítica" <?php echo e(request('priority') === 'Crítica' ? 'selected' : ''); ?>>Crítica</option>
                        <option value="Alta" <?php echo e(request('priority') === 'Alta' ? 'selected' : ''); ?>>Alta</option>
                        <option value="Media" <?php echo e(request('priority') === 'Media' ? 'selected' : ''); ?>>Media</option>
                        <option value="Baja" <?php echo e(request('priority') === 'Baja' ? 'selected' : ''); ?>>Baja</option>
                    </select>
                </div>
                <div class="col-md-3">
                    <div class="form-check pt-2">
                        <input class="form-check-input" type="checkbox" name="overdue" value="1" id="overdueCheck" <?php echo e(request('overdue') ? 'checked' : ''); ?> onchange="this.form.submit()">
                        <label class="form-check-label fw-bold text-danger" for="overdueCheck">
                            <i class="fa-solid fa-triangle-exclamation me-1"></i> Solo Vencidas
                        </label>
                    </div>
                </div>
                <div class="col-md-3 d-flex gap-2">
                    <button type="submit" class="btn btn-secondary w-100">Filtrar</button>
                    <?php if(request()->anyFilled(['status', 'priority', 'overdue'])): ?>
                        <a href="<?php echo e(route('corrective-measures.index')); ?>" class="btn btn-light border"><i class="fa-solid fa-xmark"></i></a>
                    <?php endif; ?>
                </div>
            </form>
        </div>
    </div>

    <!-- Tabla de Medidas Correctivas -->
    <div class="card card-custom">
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0">
                    <thead class="table-light">
                        <tr>
                            <th>Prioridad</th>
                            <th>Empresa / Inspección</th>
                            <th>Medida Correctiva</th>
                            <th>Responsable</th>
                            <th>Fecha Límite</th>
                            <th>Costo Estimado</th>
                            <th>Estado Actual</th>
                            <th class="text-end">Acciones</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $measures; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr class="<?php echo e($m->isOverdue() ? 'table-danger' : ''); ?>">
                                <td>
                                    <span class="badge <?php echo e($m->priority === 'Crítica' ? 'bg-danger' : ($m->priority === 'Alta' ? 'bg-warning text-dark' : 'bg-secondary')); ?>">
                                        <?php echo e($m->priority); ?>

                                    </span>
                                </td>
                                <td>
                                    <a href="<?php echo e(route('inspections.show', $m->inspection)); ?>" class="fw-bold text-dark text-decoration-none">
                                        <?php echo e($m->inspection->company->business_name ?? 'Empresa'); ?>

                                    </a>
                                    <small class="text-muted d-block"><?php echo e($m->inspection->inspection_date->format('d/m/Y')); ?></small>
                                </td>
                                <td>
                                    <div class="fw-semibold text-dark"><?php echo e($m->description); ?></div>
                                    <?php if($m->recommendations): ?>
                                        <small class="text-muted d-block"><i class="fa-regular fa-lightbulb text-warning me-1"></i> <?php echo e($m->recommendations); ?></small>
                                    <?php endif; ?>
                                </td>
                                <td><?php echo e($m->responsible_person ?? 'Sin asignar'); ?></td>
                                <td>
                                    <?php if($m->deadline): ?>
                                        <span class="<?php echo e($m->isOverdue() ? 'text-danger fw-bold' : 'text-dark'); ?>">
                                            <?php echo e($m->deadline->format('d/m/Y')); ?>

                                            <?php if($m->isOverdue()): ?> <i class="fa-solid fa-circle-exclamation ms-1"></i> <?php endif; ?>
                                        </span>
                                    <?php else: ?>
                                        <span class="text-muted">Sin plazo</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php echo e($m->estimated_cost ? '$' . number_format($m->estimated_cost, 2, ',', '.') : '-'); ?>

                                </td>
                                <td>
                                    <form action="<?php echo e(route('corrective-measures.status', $m)); ?>" method="POST" class="d-inline">
                                        <?php echo csrf_field(); ?>
                                        <select name="status" class="form-select form-select-sm <?php echo e($m->status === 'Completada' ? 'bg-success text-white' : ($m->status === 'En Progreso' ? 'bg-primary text-white' : 'bg-light')); ?>" onchange="this.form.submit()">
                                            <option value="Pendiente" <?php echo e($m->status === 'Pendiente' ? 'selected' : ''); ?>>Pendiente</option>
                                            <option value="En Progreso" <?php echo e($m->status === 'En Progreso' ? 'selected' : ''); ?>>En Progreso</option>
                                            <option value="Completada" <?php echo e($m->status === 'Completada' ? 'selected' : ''); ?>>Completada</option>
                                            <option value="Cancelada" <?php echo e($m->status === 'Cancelada' ? 'selected' : ''); ?>>Cancelada</option>
                                        </select>
                                    </form>
                                </td>
                                <td class="text-end">
                                    <a href="<?php echo e(route('inspections.show', $m->inspection)); ?>" class="btn btn-sm btn-outline-primary" title="Ir a la Inspección">
                                        <i class="fa-solid fa-arrow-up-right-from-square"></i>
                                    </a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="8" class="text-center py-4 text-muted">No se encontraron medidas correctivas con los filtros aplicados.</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
        <?php if($measures->hasPages()): ?>
            <div class="card-footer bg-white border-0 py-3">
                <?php echo e($measures->links()); ?>

            </div>
        <?php endif; ?>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\murqu\.gemini\antigravity\scratch\sistema-inspecciones-hys\resources\views/corrective_measures/index.blade.php ENDPATH**/ ?>