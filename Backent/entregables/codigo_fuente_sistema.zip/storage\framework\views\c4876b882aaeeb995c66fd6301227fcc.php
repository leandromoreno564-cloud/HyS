<?php $__env->startSection('title', 'Empresas'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid p-0">
    <div class="d-flex flex-column flex-md-row align-items-md-center justify-content-between mb-4">
        <div>
            <h3 class="fw-bold text-dark mb-1">Empresas e Instalaciones</h3>
            <p class="text-muted small mb-0">Gestión de establecimientos comerciales, industriales y obras registradas</p>
        </div>
        <div class="mt-3 mt-md-0 d-flex gap-2">
            <?php if(auth()->user()->isAdmin()): ?>
                <a href="<?php echo e(route('companies.index', array_merge(request()->query(), ['trashed' => request('trashed') ? null : 1]))); ?>" class="btn btn-outline-secondary btn-touch">
                    <i class="fa-solid fa-trash-can me-1"></i> <?php echo e(request('trashed') ? 'Ver Activas' : 'Ver Papelera'); ?>

                </a>
            <?php endif; ?>
            <a href="<?php echo e(route('companies.create')); ?>" class="btn btn-primary btn-touch shadow-sm">
                <i class="fa-solid fa-plus-circle me-2"></i> Registrar Empresa
            </a>
        </div>
    </div>

    <!-- Filtros de búsqueda -->
    <div class="card card-custom mb-4">
        <div class="card-body p-3">
            <form action="<?php echo e(route('companies.index')); ?>" method="GET" class="row g-2 align-items-center">
                <div class="col-md-5">
                    <div class="input-group">
                        <span class="input-group-text bg-white border-end-0 text-muted"><i class="fa-solid fa-magnifying-glass"></i></span>
                        <input type="text" name="search" class="form-control border-start-0" placeholder="Buscar por razón social, CUIT o contacto..." value="<?php echo e(request('search')); ?>">
                    </div>
                </div>
                <div class="col-md-3">
                    <select name="sector" class="form-select">
                        <option value="">Todos los sectores</option>
                        <?php $__currentLoopData = $sectors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sec): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($sec); ?>" <?php echo e(request('sector') === $sec ? 'selected' : ''); ?>><?php echo e($sec); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="col-md-2">
                    <select name="status" class="form-select">
                        <option value="">Todos los estados</option>
                        <option value="active" <?php echo e(request('status') === 'active' ? 'selected' : ''); ?>>Activas</option>
                        <option value="inactive" <?php echo e(request('status') === 'inactive' ? 'selected' : ''); ?>>Inactivas</option>
                    </select>
                </div>
                <div class="col-md-2 d-flex gap-2">
                    <button type="submit" class="btn btn-secondary w-100">Filtrar</button>
                    <?php if(request()->anyFilled(['search', 'sector', 'status'])): ?>
                        <a href="<?php echo e(route('companies.index')); ?>" class="btn btn-light border"><i class="fa-solid fa-xmark"></i></a>
                    <?php endif; ?>
                </div>
            </form>
        </div>
    </div>

    <!-- Listado de Empresas -->
    <div class="card card-custom">
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0">
                    <thead class="table-light">
                        <tr>
                            <th>Empresa / Razón Social</th>
                            <th>CUIT / RUC</th>
                            <th>Sector Industrial</th>
                            <th>Empleados</th>
                            <th>Inspectores Asignados</th>
                            <th>Inspecciones</th>
                            <th>Estado</th>
                            <th class="text-end">Acciones</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $companies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr class="<?php echo e($c->trashed() ? 'table-danger' : ''); ?>">
                                <td>
                                    <a href="<?php echo e(route('companies.show', $c)); ?>" class="fw-bold text-dark text-decoration-none">
                                        <?php echo e($c->business_name); ?>

                                    </a>
                                    <?php if($c->contact_person): ?>
                                        <div class="small text-muted"><i class="fa-solid fa-user-tie me-1"></i> <?php echo e($c->contact_person); ?></div>
                                    <?php endif; ?>
                                </td>
                                <td><code><?php echo e($c->tax_id); ?></code></td>
                                <td><span class="badge bg-light text-dark border"><?php echo e($c->industry_sector); ?></span></td>
                                <td><?php echo e($c->employee_count); ?></td>
                                <td>
                                    <div class="d-flex flex-wrap gap-1">
                                        <?php $__empty_2 = true; $__currentLoopData = $c->inspectors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $insp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_2 = false; ?>
                                            <span class="badge bg-primary-subtle text-primary border border-primary-subtle" title="<?php echo e($insp->name); ?>">
                                                <?php echo e(Str::limit($insp->name, 14)); ?>

                                            </span>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_2): ?>
                                            <span class="text-muted small">Sin asignar</span>
                                        <?php endif; ?>
                                    </div>
                                </td>
                                <td>
                                    <span class="badge bg-light text-secondary border">
                                        <i class="fa-solid fa-clipboard-check me-1 text-primary"></i> <?php echo e($c->inspections_count); ?>

                                    </span>
                                </td>
                                <td>
                                    <?php if($c->trashed()): ?>
                                        <span class="badge bg-danger">Eliminada</span>
                                    <?php elseif($c->is_active): ?>
                                        <span class="badge bg-success-subtle text-success border border-success-subtle">Activa</span>
                                    <?php else: ?>
                                        <span class="badge bg-secondary">Inactiva</span>
                                    <?php endif; ?>
                                </td>
                                <td class="text-end">
                                    <div class="btn-group">
                                        <a href="<?php echo e(route('companies.show', $c)); ?>" class="btn btn-sm btn-outline-primary" title="Ver Detalles">
                                            <i class="fa-solid fa-eye"></i>
                                        </a>

                                        <?php if(!$c->trashed()): ?>
                                            <a href="<?php echo e(route('inspections.create', ['company_id' => $c->id])); ?>" class="btn btn-sm btn-outline-warning text-dark" title="Nueva Inspección">
                                                <i class="fa-solid fa-plus-circle"></i>
                                            </a>

                                            <a href="<?php echo e(route('companies.edit', $c)); ?>" class="btn btn-sm btn-outline-secondary" title="Editar">
                                                <i class="fa-solid fa-pen-to-square"></i>
                                            </a>

                                            <?php if(auth()->user()->isAdmin()): ?>
                                                <form action="<?php echo e(route('companies.destroy', $c)); ?>" method="POST" class="d-inline" onsubmit="return confirm('¿Está seguro de enviar esta empresa a la papelera?');">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('DELETE'); ?>
                                                    <button type="submit" class="btn btn-sm btn-outline-danger" title="Eliminar">
                                                        <i class="fa-solid fa-trash-can"></i>
                                                    </button>
                                                </form>
                                            <?php endif; ?>
                                        <?php else: ?>
                                            <form action="<?php echo e(route('companies.restore', $c->id)); ?>" method="POST" class="d-inline">
                                                <?php echo csrf_field(); ?>
                                                <button type="submit" class="btn btn-sm btn-success" title="Restaurar Empresa">
                                                    <i class="fa-solid fa-trash-can-arrow-up me-1"></i> Restaurar
                                                </button>
                                            </form>
                                        <?php endif; ?>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="8" class="text-center py-4 text-muted">No se encontraron empresas con los criterios seleccionados.</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
        <?php if($companies->hasPages()): ?>
            <div class="card-footer bg-white border-0 py-3">
                <?php echo e($companies->links()); ?>

            </div>
        <?php endif; ?>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\murqu\.gemini\antigravity\scratch\sistema-inspecciones-hys\resources\views/companies/index.blade.php ENDPATH**/ ?>