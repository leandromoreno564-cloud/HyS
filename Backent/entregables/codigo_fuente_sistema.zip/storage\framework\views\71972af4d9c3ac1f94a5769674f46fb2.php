<?php $__env->startSection('title', 'Registrar Empresa'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid p-0" style="max-width: 900px;">
    <div class="d-flex align-items-center justify-content-between mb-4">
        <div>
            <h3 class="fw-bold text-dark mb-1">Registrar Nueva Empresa</h3>
            <p class="text-muted small mb-0">Alta de razón social, sector industrial y parámetros de establecimiento</p>
        </div>
        <a href="<?php echo e(route('companies.index')); ?>" class="btn btn-outline-secondary btn-touch">
            <i class="fa-solid fa-arrow-left me-2"></i> Volver
        </a>
    </div>

    <div class="card card-custom">
        <div class="card-body p-4">
            <form action="<?php echo e(route('companies.store')); ?>" method="POST">
                <?php echo csrf_field(); ?>

                <div class="row g-3">
                    <div class="col-md-8">
                        <label for="business_name" class="form-label fw-semibold">Razón Social / Nombre Comercial <span class="text-danger">*</span></label>
                        <input type="text" name="business_name" id="business_name" class="form-control" value="<?php echo e(old('business_name')); ?>" placeholder="Ej: Aceros Industriales S.A." required>
                    </div>

                    <div class="col-md-4">
                        <label for="tax_id" class="form-label fw-semibold">CUIT / RUC <span class="text-danger">*</span></label>
                        <input type="text" name="tax_id" id="tax_id" class="form-control" value="<?php echo e(old('tax_id')); ?>" placeholder="Ej: 30-12345678-9" required>
                    </div>

                    <div class="col-md-6">
                        <label for="industry_sector" class="form-label fw-semibold">Sector Industrial <span class="text-danger">*</span></label>
                        <select name="industry_sector" id="industry_sector" class="form-select" required>
                            <option value="">Seleccione sector...</option>
                            <option value="Metalmecánica" <?php echo e(old('industry_sector') === 'Metalmecánica' ? 'selected' : ''); ?>>Metalmecánica</option>
                            <option value="Construcción" <?php echo e(old('industry_sector') === 'Construcción' ? 'selected' : ''); ?>>Construcción</option>
                            <option value="Química y Farmacéutica" <?php echo e(old('industry_sector') === 'Química y Farmacéutica' ? 'selected' : ''); ?>>Química y Farmacéutica</option>
                            <option value="Logística y Transporte" <?php echo e(old('industry_sector') === 'Logística y Transporte' ? 'selected' : ''); ?>>Logística y Transporte</option>
                            <option value="Alimentos y Bebidas" <?php echo e(old('industry_sector') === 'Alimentos y Bebidas' ? 'selected' : ''); ?>>Alimentos y Bebidas</option>
                            <option value="Agropecuario" <?php echo e(old('industry_sector') === 'Agropecuario' ? 'selected' : ''); ?>>Agropecuario</option>
                            <option value="Servicios y Comercio" <?php echo e(old('industry_sector') === 'Servicios y Comercio' ? 'selected' : ''); ?>>Servicios y Comercio</option>
                            <option value="Minería y Energía" <?php echo e(old('industry_sector') === 'Minería y Energía' ? 'selected' : ''); ?>>Minería y Energía</option>
                        </select>
                    </div>

                    <div class="col-md-6">
                        <label for="employee_count" class="form-label fw-semibold">Cantidad de Empleados <span class="text-danger">*</span></label>
                        <input type="number" name="employee_count" id="employee_count" class="form-control" value="<?php echo e(old('employee_count', 10)); ?>" min="1" required>
                    </div>

                    <div class="col-md-12">
                        <label for="address" class="form-label fw-semibold">Dirección de la Planta / Establecimiento</label>
                        <input type="text" name="address" id="address" class="form-control" value="<?php echo e(old('address')); ?>" placeholder="Calle, Número, Parque Industrial o Localidad">
                    </div>

                    <div class="col-md-6">
                        <label for="phone" class="form-label fw-semibold">Teléfono de Contacto</label>
                        <input type="text" name="phone" id="phone" class="form-control" value="<?php echo e(old('phone')); ?>" placeholder="+54 11 0000-0000">
                    </div>

                    <div class="col-md-6">
                        <label for="email" class="form-label fw-semibold">Correo Electrónico Institucional</label>
                        <input type="email" name="email" id="email" class="form-control" value="<?php echo e(old('email')); ?>" placeholder="contacto@empresa.com">
                    </div>

                    <div class="col-md-6">
                        <label for="contact_person" class="form-label fw-semibold">Persona de Contacto / Cargo</label>
                        <input type="text" name="contact_person" id="contact_person" class="form-control" value="<?php echo e(old('contact_person')); ?>" placeholder="Ej: Ing. Jorge Pérez (Jefe de Seguridad)">
                    </div>

                    <div class="col-md-6">
                        <label for="website" class="form-label fw-semibold">Sitio Web</label>
                        <input type="url" name="website" id="website" class="form-control" value="<?php echo e(old('website')); ?>" placeholder="https://www.empresa.com">
                    </div>

                    <?php if(auth()->user()->isAdmin()): ?>
                        <div class="col-12"><hr class="my-2 text-muted"></div>
                        <div class="col-12">
                            <label class="form-label fw-semibold">Asignar Inspectores Responsables</label>
                            <div class="row g-2">
                                <?php $__currentLoopData = $inspectors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $insp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="col-md-6">
                                        <div class="form-check p-2 border rounded">
                                            <input class="form-check-input ms-0 me-2" type="checkbox" name="inspector_ids[]" value="<?php echo e($insp->id); ?>" id="insp_<?php echo e($insp->id); ?>">
                                            <label class="form-check-label fw-semibold" for="insp_<?php echo e($insp->id); ?>">
                                                <?php echo e($insp->name); ?>

                                                <small class="text-muted d-block"><?php echo e($insp->license_number ?? $insp->email); ?></small>
                                            </label>
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                    <?php endif; ?>

                    <div class="col-12 mt-3">
                        <div class="form-check form-switch">
                            <input class="form-check-input" type="checkbox" role="switch" id="is_active" name="is_active" value="1" checked>
                            <label class="form-check-label fw-semibold" for="is_active">Empresa Activa</label>
                        </div>
                    </div>

                    <div class="col-12 mt-4 text-end">
                        <a href="<?php echo e(route('companies.index')); ?>" class="btn btn-light border btn-touch px-3 me-2">Cancelar</a>
                        <button type="submit" class="btn btn-primary btn-touch px-4">
                            <i class="fa-solid fa-check me-2"></i> Registrar Empresa
                        </button>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\murqu\.gemini\antigravity\scratch\sistema-inspecciones-hys\resources\views\companies\create.blade.php ENDPATH**/ ?>